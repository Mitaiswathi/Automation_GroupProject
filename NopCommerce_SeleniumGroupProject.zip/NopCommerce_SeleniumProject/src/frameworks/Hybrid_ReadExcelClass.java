package frameworks;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;



public class Hybrid_ReadExcelClass
{
	public void readExcel(WebDriver driver) throws Exception 
	{

	//Excel
			FileInputStream file =new FileInputStream("./Hybrid_NopCommerce.xlsx");
			XSSFWorkbook w = new XSSFWorkbook(file);
			XSSFSheet s= w.getSheet("Hybrid");
			int rowSize=s.getLastRowNum();
			System.out.println("No of Rows:" +rowSize);
			Hybrid_OperationalClass o=new Hybrid_OperationalClass();
			for (int i=1; i<=rowSize;i++)
			{
				String username=s.getRow(i).getCell(1).getStringCellValue();
				String password= s.getRow(i).getCell(2).getStringCellValue();
				System.out.println(username+"\t\t"+password);
				try
				{
					for(int j=1; j<=rowSize; j++) 
					{
						String key =s.getRow(j).getCell(0).getStringCellValue();
						if(key.equals("MaximizeBrowser"))
						{
							o.maximizeBrowser(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("URL"))
						{
							o.getUrl(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("ClickLogin"))
						{
							o.clickLogin(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Username"))
						{
							o.enterUsername(driver, username);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Password"))
						{
							o.enterPassword(driver, password);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Login"))
						{
							o.clickOnLogin(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						
						else if(key.equals("Logout"))
						{
							o.clickOnLogout(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						
					}
					System.out.println("Valid Credentials");
					System.out.println("");
					s.getRow(i).createCell(3).setCellValue("Valid Credentials.");
				}

				catch(Exception e)
				{
					System.out.println("Invalid Credentials");
					System.out.println("");
					s.getRow(i).createCell(3).setCellValue("Invalid Credentials.");
				}
	
			}
			FileOutputStream out=new FileOutputStream("./Hybrid_NopCommerce.xlsx");
			w.write(out);

			o.closeBrowser(driver);
		}
}
			
