package frameworks;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom.NopCommerce;

public class DDT_Nopcommerce {

	public static void main(String[] args) throws Exception
	{
		//store Excel file path
		FileInputStream file=new FileInputStream("./DDT_Nopcommerce.xlsx");
		//JVM will reach to Excel File
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("DataDriven");

		//To store total no. of row
		int rowsize =s.getLastRowNum();
		System.out.println("No. of credentials: "+rowsize);

		//Launch Browser
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		 NopCommerce nc= new NopCommerce();	
		//For loop
			for(int i=1;i<=rowsize;i++)
			{
				//store username and password in variables
				String username =s.getRow(i).getCell(0).getStringCellValue();
				String password =s.getRow(i).getCell(1).getStringCellValue();

				//Display pair of credential on console
				System.out.println(username+"\t\t"+password);

				//Handle exception(Invalid exception)
				try
				{
	        nc.maximizeBrowser(driver);
		    nc.getUrl(driver);
		    Thread.sleep(2000);
		    nc.clickLogin(driver);
		    Thread.sleep(2000);
		    nc.enterUsername(driver,username);
		    Thread.sleep(2000);
		    nc.enterPassword(driver,password);
		    Thread.sleep(2000);
		    nc.clickOnLogin(driver);
		    Thread.sleep(2000);
		    nc.clickOnLogout(driver);

			//Update testResult
			System.out.println("Valid credentials");
			System.out.println("");
			s.getRow(i).createCell(2).setCellValue("Valid Credential");
		}
		catch(Exception e)
		{
			System.out.println("Invalid credentials");
			System.out.println("");
			s.getRow(i).createCell(2).setCellValue("Invalid Credential");
		}

	}
	//write TestResult on ExcelSheet
	FileOutputStream out=new FileOutputStream("./DDT_Nopcommerce.xlsx");
	w.write(out);

	//close browser
	driver.close();
}

	

}
