package frameworks;

import org.testng.annotations.Test;

import pom.NopCommerce;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ParallelTesting_NopCommerce 
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	 {
		 System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
	  }
  @Test
  public void nopCommerce() throws Exception
  {
	  NopCommerce nc= new NopCommerce();	
		nc.maximizeBrowser(driver);
		nc.getUrl(driver);
		Thread.sleep(2000);
		nc.clickLogin(driver);
		Thread.sleep(2000);
		nc.enterUsername(driver,"mitai.swathi@outlook.com");
		Thread.sleep(2000);
		nc.enterPassword(driver,"Swathi@123");
		Thread.sleep(2000);
		nc.clickOnLogin(driver);
		Thread.sleep(2000);
		nc.clickOnLogout(driver);
  }
 

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
