package frameworks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Hybrid_OperationalClass
{
	public void maximizeBrowser(WebDriver driver)
	{
		driver.manage().window().maximize() ;
	}
	public void getUrl(WebDriver driver)
	{
		driver.get("https://demo.nopcommerce.com/");
	}
	public void clickLogin(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
	public void enterUsername(WebDriver driver,String usn)
	{
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(usn);
	}
	public void enterPassword(WebDriver driver,String pwd)
	{
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pwd);
	}
	public void clickOnLogin(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
	}
	public void clickOnLogout(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
	public void closeBrowser(WebDriver driver)
	{
		driver.close();
	}

}
