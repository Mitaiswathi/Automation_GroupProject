package mainFunctionalities;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Login_LogoutUsingScanner {

	public static void main(String[] args) throws Exception 
	{

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username:");
		String usn=sc.next();
		System.out.println("Enter password:");
		String pwd=sc.next();
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);

		//click  login 
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		//Username
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(usn);
		Thread.sleep(2000);

		//Password
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pwd);
		Thread.sleep(6000);

		//login
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
		Thread.sleep(2000);

		//Logout
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		driver.close();


	}

}
