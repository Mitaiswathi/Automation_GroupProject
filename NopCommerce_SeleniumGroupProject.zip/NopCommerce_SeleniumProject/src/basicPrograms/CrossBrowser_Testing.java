package basicPrograms;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class CrossBrowser_Testing {

	public static void main(String[] args) throws Exception
	{
		System.out.println("Enter 1 for Google chrome.\nEnter 2 for Microsoft edge.\n Enter 3 for Mozilla firefox.");
		Scanner sc=new Scanner(System.in);
		int input= sc.nextInt();
		WebDriver driver=null;
		switch(input)
		{
		case 1:
			System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
			driver= new ChromeDriver();
			break;
		case 2:
			System.setProperty("webdriver.msedge.driver", ".\\BrowserExtension\\msedgedriver.exe");
			driver=new EdgeDriver();
			break;

			//case 3:
			//	System.setProperty("WebDriver.gecko.driver", "C:\\Users\\Sai kumar\\OneDrive\\Documents\\AutomationTesting\\Browser Extension\\geckodriver.exe");
			//   driver=new FireFoxDriver();

			//break;
		default:System.out.println("Invalid input.");
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//URL
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);


		//click on login 
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		//Username
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("mitai.swathi@outlook.com");
		Thread.sleep(2000);

		//Password
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("Swathi@12345");
		Thread.sleep(6000);

		//login
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
		Thread.sleep(2000);

		//Logout
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		driver.close();


	}

}
