package basicPrograms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import pom.NopCommerce;

public class Mouse_Hover {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		NopCommerce nc=new NopCommerce();
		nc.maximizeBrowser(driver);
		Thread.sleep(2000);
		nc.getUrl(driver);
		
        
        Actions a =new Actions(driver);
        List<WebElement> ls=driver.findElements(By.xpath("/html/body/div[6]/div[2]/ul/li"));
        int size=ls.size();
        System.out.println("No. of Elements: "+size);
        for(int i=1;i<=size;i++)
        {
        	Thread.sleep(2000);
        	System.out.println(driver.findElement(By.xpath("/html/body/div[6]/div[2]/ul/li["+i+"]")).getText());
        	a.moveToElement(driver.findElement(By.xpath("/html/body/div[6]/div[2]/ul/li["+i+"]"))).click().perform();
        	
        }
        driver.close();
	}

}
